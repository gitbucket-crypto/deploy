import socket
import subprocess, sys
import requests
import uuid
from random import randbytes
import hashlib
from datetime import datetime

##############################################################################################################
#python3 -m venv env
#source env/bin/activate

TCP_IP = sys.argv[1]
TCP_PORT = 55502
BUFFER_SIZE = 1024  # Normally 1024, but we want fast response
NUMBER_OF_CONECTIONS = 1
EOL = '\n'

data_e_hora_atuais = datetime.now()
DATAHORA = data_e_hora_atuais.strftime('%Y/%m/%d %H:%M')

##############################################################################################################
#subprocess.run("killall -s 9 python3", shell = True, executable="/bin/bash")
soc = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
soc.bind((TCP_IP, TCP_PORT)) 
soc.listen(NUMBER_OF_CONECTIONS)


conn, rmc_addr = soc.accept()

print ('1 - ENDEREÇO DE CONEXAO:', rmc_addr)

mac_address = uuid.getnode()
mac_address_hex = ''.join(['{:02x}'.format((mac_address >> elements) & 0xff) for elements in range(0,8*6,8)][::-1])

publicIP = requests.get('http://ipinfo.io/json').json()['ip']

localIP = [(s.connect(('8.8.8.8', 53)), s.getsockname()[0], s.close()) for s in [socket.socket(socket.AF_INET, socket.SOCK_DGRAM)]][0][1]

csrf = (hashlib.md5(randbytes(32))).hexdigest()

print(csrf)

rmcIP = rmc_addr[0];
print ('--- ENDEREÇO DE CONEXAO:'+ str(rmc_addr))
go = True
res= '';
while(go):
  data = conn.recv(BUFFER_SIZE)    
  data = str(bytes.hex(data)) 
  if not data:
     print('NO DATA !!!')     
     go = False
     break
  if len(data)>512:  
     #data = str(bytes.hex(data))      
     print(data)
     p= {
     		'csrf'     : csrf,
     		'nucMac'   : str(mac_address_hex),
     		'publicIP' : publicIP,
     		'localIP'  : localIP,
     		'rmcIP'    : rmcIP,
     		'data'     : data ,
     		'timestamp': DATAHORA
     	}
     print(p)
     r = requests.get('http://boe-php.eletromidia.com.br/server.php', params =p)
     print('http://boe-php.eletromidia.com.br/server.php')
     print(r.headers)
     print(r.status_code)     
     soc.close()
     go =False;
     raise Exception(subprocess.run("killall -s 9 python3", shell = True, executable="/bin/bash"))

    
  
